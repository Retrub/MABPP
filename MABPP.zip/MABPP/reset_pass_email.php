<?php
include 'proc/user.proc.php';
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Slaptažodžio atstatymas</title>
    <link rel="stylesheet" href="html/Styles/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" />
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,700' rel='stylesheet' type='text/css'>
    <link href="html/css/font-awesome.min.css" rel="stylesheet">
    <link href="html/css/bootstrap.min.css" rel="stylesheet">
    <link href="html/css/templatemo-style.css" rel="stylesheet">
    <style>
        html,
        body {
            height: 100%;
            margin: 0;
        }

        body {
            background-image: url('https://img.besthqwallpapers.com/Uploads/8-3-2020/124199/man-lions-city-18-g-4k-road-2020-buses-passenger-transport.jpg');
            background-position-x: 20%;
            background-size: cover;
            overflow: hidden;

        }
    </style>
</head>

<div class="templatemo-flex-row">
    <div class="templatemo-sidebar">
        <header class="templatemo-site-header">
            <div class="square"></div>
            <h1><a style="color:white; font-weight:500;" href="welcome.php"> MABPP</a></h1>
            <hr>
            <br>
        </header>
    </div>
</div>
<div style="background: rgba(36, 206, 172, 0.6); font-size: 25px; display: flex; margin-top: -50px; align-items: center; justify-content: center;">
    <p>Autobusų bilietai</p>
</div>
<body>
    <div class="container">
        <div class="wrapper">
            <div class="title"><span>Slaptažodžio atstatymas</span></div>
            <form method="post" enctype="multipart/form-data">

                <label for="exampleInputEmail1">Įveskite užmiršto slaptažodžio el. paštą:</label>

                <div class="row">
                    <i class="fas fa-envelope"></i>
                    <input type="email" placeholder="El. paštas" id="email" name="email" required>
                </div>

                <?php
                if (isset($_POST['password-reset-token']) && $_POST['email']) {
                    $user = new User();
                    $user->ResetPasswordCreate($_POST["email"]);
                }
                ?>
                <div class="row button">
                    <input type="submit" name="password-reset-token" value="Siųsti">
                </div>
                <div class="signup-link"><a href="login.php">Grįžti į prisijungimo puslapį</a></div>
            </form>
        </div>
    </div>
</body>

</html>