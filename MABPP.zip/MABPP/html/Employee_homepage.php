<?php
    session_start();
    if($_SESSION['User'] != 2)
    {
        header("Location: ../welcome.php");
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>MABPP. Vartotojas</title>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,700' rel='stylesheet' type='text/css'>
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/templatemo-style.css" rel="stylesheet">
    <script src="js/jquery-1.11.2.min.js"></script>
    <script src="js/jquery-migrate-1.2.1.min.js"></script>
</head>
<style>
    html,
    body {
        height: 100%;
        margin: 0;
    }

    body {
        background-image: url('https://img.besthqwallpapers.com/Uploads/8-3-2020/124199/man-lions-city-18-g-4k-road-2020-buses-passenger-transport.jpg');
        background-position-x: 20%;
        background-size: cover;
        overflow-y: scroll;

    }

    img {
        max-width: 250px;
    }
</style>
</head>

<div class="templatemo-flex-row">
    <div class="templatemo-sidebar">
        <header class="templatemo-site-header">
            <div class="square"></div>
            <h1><a style="color:white; font-weight:500;" href="Employee_homepage.php"> MABPP</a></h1>
            <hr>
            <br>
        </header>
    </div>
</div>
<div style="background: rgba(36, 206, 172, 0.6); font-size: 25px; display: flex; margin-top: -50px; align-items: center; justify-content: center;">
    <p>Autobusų bilietai</p>
</div>

<body>
    <!-- Left column -->
    <div class="templatemo-flex-row">
        <div class="templatemo-sidebar">
            <div class="mobile-menu-icon">
                <i class="fa fa-bars"></i>
            </div>
            <nav class="templatemo-left-nav">
                <ul>
                    <li><a href="Employee_homepage.php"><i class="fa fa-home fa-fw"></i>Pradžia</a></li>
                    <li><a href="#"><i class="fa fa-bar-chart fa-fw"></i>Tikrinti bilietą</a></li>
                    <li><a href="maršruto-paieška-emp.php"><i class="fa fa-bar-chart fa-fw"></i>Maršrutų paieška</a></li>
                    <li><a href="#"><i class="fa fa-sliders fa-fw"></i>Mano užsakymai</a></li>
                    <li><a href="Nustatymai-emp.php"><i class="fa fa-sliders fa-fw"></i>Nustatymai</a></li>
                    <li><a href="#"><i class="fa fa-sliders fa-fw"></i>Kontaktai</a></li>
                    <li><a href="../proc/logout.php"><i class="fa fa-eject fa-fw"></i>Atsijungti</a></li>
                </ul>
            </nav>
        </div>
        <!-- Main content -->
        <div class="templatemo-content col-1 light-gray-bg">
            <div class="templatemo-content-container">
                <div class="templatemo-flex-row flex-content-row">
                    <div class="templatemo-content-widget white-bg col-2">
                        <div class="square"></div>
                        <h2 class="templatemo-inline-block">Naujienos</h2>
                        <hr>
                        <div style="display: block;">
                            <div style="float:right; padding:15px;">
                                <img src="images/bicycle.jpg" alt="dviratis.jpg">
                            </div>
                            <div style="padding: 10px; display:block">
                                <H4>Why do we use it?</H4>
                                <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. </p>
                            </div>
                        </div>
                        <hr>
                        <div style="display: block;">
                            <div style="float:left; padding:15px;">
                                <img src="images/profile-photo.jpg" alt="human.jpg">
                            </div>
                            <div style="padding: 10px; display: block;">
                                <H4>Where does it come from?</H4>
                                <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <footer class="text-right">
                    <p>Copyright &copy; 2022 MABPP </p>
                </footer>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            if ($.browser.mozilla) {
                $(window).bind('resize', function(e) {
                    if (window.RT) clearTimeout(window.RT);
                    window.RT = setTimeout(function() {
                        this.location.reload(false);
                    }, 200);
                });
            } else {
                $(window).resize(function() {
                    drawChart();
                });
            }
        });
    </script>
    <script type="text/javascript" src="js/templatemo-script.js"></script>
</body>

</html>