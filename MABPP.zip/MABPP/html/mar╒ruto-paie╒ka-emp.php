<?php
session_start();
if($_SESSION['User'] != 2)
{
    header("Location: ../welcome.php");
}
include '../proc/client.proc.php';
$client = new Client();
$fetchData = $client->GetAllRoutes();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Maršruto paieška</title>
    <meta name="description" content="">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" />
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/templatemo-style.css" rel="stylesheet">
    <style>
        html,
        body {
            height: 100%;
            margin: 0;
        }

        body {
            background-image: url('https://img.besthqwallpapers.com/Uploads/8-3-2020/124199/man-lions-city-18-g-4k-road-2020-buses-passenger-transport.jpg');
            background-position-x: 20%;
            background-size: cover;
            overflow-y: scroll;
        }
    </style>
</head>

<div class="templatemo-flex-row">
    <div class="templatemo-sidebar">
        <header class="templatemo-site-header">
            <div class="square"></div>
            <h1><a style="color:white; font-weight:500;" href="Employee_homepage.php"> MABPP</a></h1>
            <hr>
            <br>
        </header>
    </div>
</div>
<div style="background: rgba(36, 206, 172, 0.6); font-size: 25px; display: flex; margin-top: -50px; align-items: center; justify-content: center;">
    <p>Autobusų bilietai</p>
</div>

<body>
    <!-- Left column -->
    <div class="templatemo-flex-row">
        <div class="templatemo-sidebar">
            <div class="mobile-menu-icon">
                <i class="fa fa-bars"></i>
            </div>
            <nav class="templatemo-left-nav">
                <ul>
                <li><a href="Employee_homepage.php"><i class="fa fa-home fa-fw"></i>Pradžia</a></li>
                    <li><a href="#"><i class="fa fa-bar-chart fa-fw"></i>Tikrinti bilietą</a></li>
                    <li><a href="maršruto-paieška-emp.php"><i class="fa fa-bar-chart fa-fw"></i>Maršrutų paieška</a></li>
                    <li><a href="#"><i class="fa fa-sliders fa-fw"></i>Mano užsakymai</a></li>
                    <li><a href="Nustatymai-emp.php"><i class="fa fa-sliders fa-fw"></i>Nustatymai</a></li>
                    <li><a href="#"><i class="fa fa-sliders fa-fw"></i>Kontaktai</a></li>
                    <li><a href="../proc/logout.php"><i class="fa fa-eject fa-fw"></i>Atsijungti</a></li>
                </ul>
            </nav>
        </div>
<body>
    <!-- Main content -->
    <div class="templatemo-content col-1 light-gray-bg">
        <div class="templatemo-content-container">
            <div class="templatemo-flex-row flex-content-row">
            </div>
            <div class="templatemo-flex-row flex-content-row">
                <div class="col-1">
                    <div class="panel panel-default templatemo-content-widget white-bg no-padding templatemo-overflow-hidden">
                        <div class="templatemo-flex-row flex-content-row">
                            <h2 class="templatemo" style="margin-left: 120px;">Maršrutų paieška</h2>
                            <hr>
                        </div>
                        <form method="post" enctype="multipart/form-data">
                            <div class="row form-group">
                                <div class="col-lg-12 has-success form-group">
                                    <label class="control-label" for="inputWithSuccess">Pradinė stotelė</label>
                                    <input type="text" name="prad" class="form-control" id="inputWithSuccess" style="width: 50vmin">
                                </div>
                                <div class="col-lg-12 has-warning form-group">
                                    <label class="control-label" for="inputWithWarning">Galutinė stotelė</label>
                                    <input type="text" name="gal" class="form-control" id="inputWithWarning" style="width: 50vmin">
                                </div>
                                <div class="col-lg-12 has-error form-group">
                                    <label class="control-label" for="inputWithError">Išvykimo laikas</label>
                                    <input type="time" name="isv" class="form-control" id="inputWithError" style="width: 50vmin">
                                </div>
                                <div class="col-lg-12 has-error form-group">
                                    <label class="control-label" for="inputWithError">Atvykimo laikas</label>
                                    <input type="time" name="atv" class="form-control" id="inputWithError" style="width: 50vmin">
                                </div>
                                <div class="form-group text-left">
                                    <button type="submit" name="save" class="templatemo-blue-button" style="margin-left: 30vmin;">Ieškoti</button>
                                </div>
                            </div>
                        </form>

                        <?php
                        if (isset($_POST['save'])) {
                            $client = new Client();
                            $routes = $client->SearchRoute($_POST['prad'], $_POST['gal'], $_POST['isv'], $_POST['atv']);
                            if (mysqli_num_rows($routes) == 0) {
                                echo "<h4>Maršrutas nerastas</h4><br>";
                            } else {
                        ?>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Pradinė st.</th>
                                                <th>Galutinė st.</th>
                                                <th>Išvykimo l.</th>
                                                <th>Atvykimo l.</th>
                                                <th>Parinktys</th>
                                        </thead>
                                        <tbody>
                                            <?php
                                            while ($row  = mysqli_fetch_array($routes)) {
                                            ?>
                                                <tr>
                                                    <td><?php echo $row['pradine'] ?? ''; ?></td>
                                                    <td><?php echo $row['galutine'] ?? ''; ?></td>
                                                    <td><?php echo $row['isvykimas'] ?? ''; ?></td>
                                                    <td><?php echo $row['atvykimas'] ?? ''; ?></td>
                                                    <td><input type="button" value="Pirkti"></td>
                                                </tr>
                                            <?php
                                            } ?>
                                        </tbody>
                                    </table>
                                </div>
                        <?php
                            }
                        }
                        ?>

                        <Br>
                        <div class="panel-heading templatemo-position-relative">
                            <h2 class="text-uppercase">Pavyzdiniai maršrutai</h2>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>Pradinė st.</th>
                                        <th>Galutinė st.</th>
                                        <th>Išvykimo l.</th>
                                        <th>Atvykimo l.</th>
                                        <th>Parinktys</th>
                                </thead>
                                <tbody>
                                    <?php
                                    if (is_array($fetchData)) {
                                        $sn = 1;
                                        foreach ($fetchData as $data) {
                                    ?>
                                            <tr>
                                                <td><?php echo $data['pradine'] ?? ''; ?></td>
                                                <td><?php echo $data['galutine'] ?? ''; ?></td>
                                                <td><?php echo $data['isvykimas'] ?? ''; ?></td>
                                                <td><?php echo $data['atvykimas'] ?? ''; ?></td>
                                                <td><input type="button" value="Pirkti"></td>
                                            </tr>
                                        <?php
                                            $sn++;
                                        }
                                    } else { ?>
                                        <tr>
                                            <td colspan="8">
                                                <?php echo $fetchData; ?>
                                            </td>
                                        <tr>
                                        <?php
                                    } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div> <!-- Second row ends -->
            <footer class="text-right">
                <p>Copyright &copy; 2022 MABPP </p>
            </footer>
        </div>
    </div>
    </div>
    <script src="js/jquery-1.11.2.min.js"></script> <!-- jQuery -->
    <script src="js/jquery-migrate-1.2.1.min.js"></script> <!--  jQuery Migrate Plugin -->
    <script src="https://www.google.com/jsapi"></script> <!-- Google Chart -->
    <script>
        $(document).ready(function() {
            if ($.browser.mozilla) {
                $(window).bind('resize', function(e) {
                    if (window.RT) clearTimeout(window.RT);
                    window.RT = setTimeout(function() {
                        this.location.reload(false);
                    }, 200);
                });
            } else {
                $(window).resize(function() {
                    drawChart();
                });
            }
        });
    </script>
    <script type="text/javascript" src="js/templatemo-script.js"></script>
</body>

</html>