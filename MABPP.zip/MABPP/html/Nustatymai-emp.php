<?php
session_start();
if ($_SESSION['User'] != 2) {
  header("Location: ../welcome.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>MABPP. Vartotojas</title>
  <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,700' rel='stylesheet' type='text/css'>
  <link href="css/font-awesome.min.css" rel="stylesheet">
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/templatemo-style.css" rel="stylesheet">
  <script src="js/jquery-1.11.2.min.js"></script>
  <script src="js/jquery-migrate-1.2.1.min.js"></script>
</head>
<style>
  html,
  body {
    height: 100%;
    margin: 0;
  }

  body {
    background-image: url('https://img.besthqwallpapers.com/Uploads/8-3-2020/124199/man-lions-city-18-g-4k-road-2020-buses-passenger-transport.jpg');
    background-position-x: 20%;
    background-size: cover;
    overflow: hidden;

  }

  img {
    max-width: 250px;
  }
</style>
</head>

<div class="templatemo-flex-row">
  <div class="templatemo-sidebar">
    <header class="templatemo-site-header">
      <div class="square"></div>
      <h1><a style="color:white; font-weight:500;" href="Employee_homepage.php"> MABPP</a></h1>
      <hr>
      <br>
    </header>
  </div>
</div>
<div style="background: rgba(36, 206, 172, 0.6); font-size: 25px; display: flex; margin-top: -50px; align-items: center; justify-content: center;">
  <p>Autobusų bilietai</p>
</div>

<body>
  <div class="templatemo-flex-row">
    <div class="templatemo-sidebar">
      <div class="mobile-menu-icon">
        <i class="fa fa-bars"></i>
      </div>
      <nav class="templatemo-left-nav">
        <ul>
          <li><a href="Employee_homepage.php"><i class="fa fa-home fa-fw"></i>Pradžia</a></li>
          <li><a href="#"><i class="fa fa-bar-chart fa-fw"></i>Tikrinti bilietą</a></li>
          <li><a href="maršruto-paieška-emp.php"><i class="fa fa-bar-chart fa-fw"></i>Maršrutų paieška</a></li>
          <li><a href="#"><i class="fa fa-sliders fa-fw"></i>Mano užsakymai</a></li>
          <li><a href="Nustatymai-emp.php"><i class="fa fa-sliders fa-fw"></i>Nustatymai</a></li>
          <li><a href="#"><i class="fa fa-sliders fa-fw"></i>Kontaktai</a></li>
          <li><a href="../proc/logout.php"><i class="fa fa-eject fa-fw"></i>Atsijungti</a></li>
        </ul>
      </nav>
    </div>
    <!-- Main content -->
    <div class="templatemo-content col-1 light-gray-bg">
      <div class="templatemo-content-container">
        <div class="templatemo-content-widget white-bg">
          <h2 class="margin-bottom-10">Profilio nustatymai</h2>
          <form action="index.html" class="templatemo-login-form" method="post" enctype="multipart/form-data">
            <div class="row form-group">
              <div class="col-lg-6 col-md-6 form-group">
                <label for="inputFirstName">Vardas pavardė</label>
                <input type="text" class="form-control" id="inputFirstName" placeholder="John">
              </div>
            </div>
            <div class="row form-group">
              <div class="col-lg-6 col-md-6 form-group">
                <label for="inputEmail">El. paštas</label>
                <input type="email" class="form-control" id="inputEmail" placeholder="admin@mabpp.com">
              </div>
            </div>
            <div class="row form-group">
              <div class="col-lg-6 col-md-6 form-group">
                <label for="inputCurrentPassword">Dabartinis slaptažodis</label>
                <input type="password" class="form-control" id="inputCurrentPassword" placeholder="*********">
              </div>
            </div>
            <div class="row form-group">
              <div class="col-lg-6 col-md-6 form-group">
                <label for="inputNewPassword">Naujas slaptažodis</label>
                <input type="password" class="form-control" id="inputNewPassword">
              </div>
              <div class="col-lg-6 col-md-6 form-group">
                <label for="inputConfirmNewPassword">Pakartoti naują slaptažodį</label>
                <input type="password" class="form-control" id="inputConfirmNewPassword">
              </div>
            </div>
            <div class="form-group text-right">
              <button type="submit" class="templatemo-blue-button">Atnaujinti</button>
            </div>
          </form>
        </div>
        <footer class="text-right">
          <p>Copyright &copy;2022 MABPP</p>
        </footer>
      </div>
    </div>
  </div>
  <script src="js/jquery-1.11.2.min.js"></script> <!-- jQuery -->
  <script src="js/jquery-migrate-1.2.1.min.js"></script> <!--  jQuery Migrate Plugin -->
  <script src="https://www.google.com/jsapi"></script> <!-- Google Chart -->
  <script>
    $(document).ready(function() {
      if ($.browser.mozilla) {
        $(window).bind('resize', function(e) {
          if (window.RT) clearTimeout(window.RT);
          window.RT = setTimeout(function() {
            this.location.reload(false);
          }, 200);
        });
      } else {
        $(window).resize(function() {
          drawChart();
        });
      }
    });
  </script>
  <script type="text/javascript" src="js/templatemo-script.js"></script>
</body>

</html>