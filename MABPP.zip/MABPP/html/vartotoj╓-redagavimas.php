<?php
session_start();
if ($_SESSION['User'] != 3) {
  header("Location: ../welcome.php");
}
include("../proc/admin.proc.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>MABPP Admin</title>
  <meta name="description" content="">
  <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,700' rel='stylesheet' type='text/css'>
  <link href="css/font-awesome.min.css" rel="stylesheet">
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/templatemo-style.css" rel="stylesheet">
</head>

<body>
  <!-- Left column -->
  <div class="templatemo-flex-row">
    <div class="templatemo-sidebar">
      <header class="templatemo-site-header">
        <div class="square"></div>
        <h1><a style="color:white; font-weight:500;" href="Admin_homepage.php"> MABPP</a></h1>
      </header>
      <div class="mobile-menu-icon">
        <i class="fa fa-bars"></i>
      </div>
      <nav class="templatemo-left-nav">
        <ul>
          <li><a href="Admin_homepage.php"><i class="fa fa-home fa-fw"></i>Pradžia</a></li>
          <li><a href="vartotojų-redagavimas.php"><i class="fa fa-bar-chart fa-fw"></i>Vartotojų redagavimas</a></li>
          <li><a href="stoteliu-redagavimas.php"><i class="fa fa-database fa-fw"></i>Stotelių redagavimas</a></li>
          <li><a href="marsrutų-redagavimas.php"><i class="fa fa-map-marker fa-fw"></i>Maršrutų redagavimas</a></li>
          <li><a href="Ataskaitos.php"><i class="fa fa-users fa-fw"></i>Ataskaitos</a></li>
          <li><a href="Nustatymai.php"><i class="fa fa-sliders fa-fw"></i>Nustatymai</a></li>
          <li><a href="../proc/logout.php"><i class="fa fa-eject fa-fw"></i>Atsijungti</a></li>
        </ul>
      </nav>
    </div>
    <!-- Main content -->
    <div class="templatemo-content col-1 light-gray-bg">
      <div class="templatemo-content-container">
        <div class="templatemo-flex-row flex-content-row">

          <div class="square"></div>
          <h2 class="templatemo-inline-block">Vartotojų redagavimas</h2>
          <hr>
        </div>
        <form method="post" enctype="multipart/form-data">
          <div class="row form-group">
            <div class="col-lg-12 has-success form-group">
              <h2>Įvesti naują vartotoją<br><Br></h2>
              <label class="control-label" for="inputWithSuccess">Vardas pavardė</label>
              <input type="text" name="name" required minlength="5" class="form-control" id="inputWithSuccess">
            </div>
          </div>
          <div class="row form-group">
            <div class="col-lg-12 has-warning form-group">
              <label class="control-label" for="inputWithWarning">El. paštas</label>
              <input type="email" name="email" required class="form-control" id="inputWithWarning">
            </div>
          </div>
          <div class="row form-group">
            <div class="col-lg-12 has-error form-group">
              <label class="control-label" for="inputWithError">Rolė</label>
              <input type="text" name="role" required class="form-control" id="inputWithError">
            </div>
          </div>

          <?php
          //-----------------------------------------------
          if (isset($_POST['save'])) {
            $admin = new Admin();
            $msg = $admin->CreateNewUser($_POST['name'], $_POST['email'], $_POST['role']);
            echo $msg;
          }
          //-----------------------------------------------
          ?>

          <div class="row form-group">
            <div class="col-lg-12 has-error form-group">
              <h4>Roles:<br></h4>
              <h4>1 - klientas<br></h4>
              <h4>2 - darbuotojas<br></h4>
              <h4>3 - administratorius<br></h4>
            </div>
          </div>
          <div class="form-group text-right">
            <button type="submit" name="save" class="templatemo-blue-button">Įvesti</button>
          </div>

        </form>
        <?php //-----------------------------------------------
        if (isset($_POST['delete']) && isset($_POST['id'])) {
          $admin = new Admin();
          $msg = $admin->DeleteUser($_POST['id']);
          echo $msg;
        }
        if (isset($_POST['confirm'])) {
          $test = $_POST['erole'];

          $admin = new Admin();
          $msg = $admin->EditUser($_SESSION['id'], $_POST['ename'], $_POST['eemail'], $_POST['erole']);
          echo $msg;
        } //-----------------------------------------------
        ?>

        <div class="templatemo-flex-row flex-content-row">
          <div class="col-1">
            <div class="panel panel-default templatemo-content-widget white-bg no-padding templatemo-overflow-hidden">
              <i class="fa fa-times"></i>

              <div class="panel-heading templatemo-position-relative">
                <h2 class="text-uppercase">Vartotojai</h2>
              </div>
              <div class="table-responsive">
                <table class="table table-striped table-bordered">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Vardas Pavardė</th>
                      <th>El. Paštas</th>
                      <th>Role</th>
                      <th>Veiksmai</th>

                  </thead>
                  <tbody>
                    <?php
                    $data = new Admin();
                    $fetchData = $data->GetAllUsers();
                    if (is_array($fetchData)) {
                      $sn = 1;
                      foreach ($fetchData as $data) {
                    ?>
                        <tr>
                          <td><?php echo $data['ID'] ?? ''; ?></td>
                          <td><?php echo $data['name'] ?? ''; ?></td>
                          <td><?php echo $data['email'] ?? ''; ?></td>
                          <td><?php echo $data['role'] ?? ''; ?></td>
                          <td>
                            <form method="post" style="display:inline;">
                              <button type="submit" name="delete" class="templatemo-blue-button" style="float: left; margin-right: 10px; margin-bottom: 5px;">Trinti</button>
                              <button type="submit" name="edit" class="templatemo-blue-button" style="float: left;">Redaguoti</button>
                          </td>
                          <input type="hidden" name="id" value="<?php echo $data['ID']; ?>">
                          </form>
                        </tr>
                      <?php
                        $sn++;
                      }
                    } else { ?>
                      <tr>
                        <td colspan="8">
                          <?php echo $fetchData; ?>
                        </td>
                      <tr>
                      <?php
                    } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        <!-- Second row ends -->

        <?php if (isset($_POST['edit']) && isset($_POST['id'])) {
          $_SESSION['id'] = $_POST['id'];
        ?>

          <div class="templatemo-flex-row flex-content-row">
            <div class="col-1">
              <div class="panel panel-default templatemo-content-widget white-bg no-padding templatemo-overflow-hidden">
                <i class="fa fa-times"></i>
                <div class="panel-heading templatemo-position-relative">
                  <h2 class="text-uppercase">Redaguoti vartotoja</h2>
                </div>
                <div>
                  <form method="post">
                    <div class="row form-group">
                      <div class="col-lg-12 has-success form-group">
                        <label class="control-label" for="inputWithSuccess">Vardas pavardė</label>
                        <input type="text" name="ename" class="form-control" id="inputWithSuccess">
                      </div>
                    </div>
                    <div class="row form-group">
                      <div class="col-lg-12 has-warning form-group">
                        <label class="control-label" for="inputWithWarning">El. paštas</label>
                        <input type="email" name="eemail" class="form-control" id="inputWithWarning">
                      </div>
                    </div>
                    <div class="row form-group">
                      <div class="col-lg-12 has-error form-group">
                        <label class="control-label" for="inputWithError">Rolė</label>
                        <input type="text" name="erole" class="form-control" id="inputWithError">
                      </div>
                    </div>
                    <div class="row form-group">
                      <div class="col-lg-12 has-error form-group">
                        <h4>Roles:<br></h4>
                        <h4>1 - klientas<br></h4>
                        <h4>2 - darbuotojas<br></h4>
                        <h4>3 - administratorius<br></h4>
                      </div>
                    </div>
                    <div class="form-group text-right">
                      <button type="submit" name="confirm" class="templatemo-blue-button">Redaguoti</button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          <?php } ?>
          <footer class="text-right">
            <p>Copyright &copy; 2022 MABPP </p>
          </footer>
          </div>
      </div>
    </div>
    <script src="js/jquery-1.11.2.min.js"></script>
    <script src="js/jquery-migrate-1.2.1.min.js"></script>
    <script>
      $(document).ready(function() {
        if ($.browser.mozilla) {
          $(window).bind('resize', function(e) {
            if (window.RT) clearTimeout(window.RT);
            window.RT = setTimeout(function() {
              this.location.reload(false);
            }, 200);
          });
        } else {
          $(window).resize(function() {});
        }
      });
    </script>
    <script type="text/javascript" src="js/templatemo-script.js"></script>
</body>

</html>