<?php
session_start();
if(!isset($_SESSION['User'])){
    $_SESSION['User'] = 9;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Mobili autobusų bilietų pirkimo programėlė</title>
    <link rel="stylesheet" href="html/Styles/welcomepage.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" />
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,700' rel='stylesheet' type='text/css'>
    <link href="html/css/font-awesome.min.css" rel="stylesheet">
    <link href="html/css/bootstrap.min.css" rel="stylesheet">
    <link href="html/css/templatemo-style.css" rel="stylesheet">
</head>

<div class="templatemo-flex-row">
    <div class="templatemo-sidebar">
        <header class="templatemo-site-header">
            <div class="square"></div>
            <h1><a style="color:white; font-weight:500;" href="welcome.php"> MABPP</a></h1>
            <hr>
            <br>
        </header>
    </div>
</div>
<div style="background: rgba(36, 206, 172, 0.6); font-size: 25px; display: flex; margin-top: -50px; align-items: center; justify-content: center;">
    <p>Autobusų bilietai</p>
</div>

<body style="background-image: url('https://img.besthqwallpapers.com/Uploads/8-3-2020/124199/man-lions-city-18-g-4k-road-2020-buses-passenger-transport.jpg');
                                    background-position-x: 20%; background-size: cover; overflow: hidden;">
    <div class="container">
        <div>
            <a class="semi-transparent-button" href="login.php">Prisijungimas prie sistemos</a>
        </div>
    </div>
</body>

</html>