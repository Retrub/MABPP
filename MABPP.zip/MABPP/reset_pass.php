<?php
include 'proc/user.proc.php';
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Slaptažodžio atstatymas</title>
    <link rel="stylesheet" href="html/Styles/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" />
</head>

<body>
    <div class="container">
        <div class="wrapper">
            <div class="title"><span>Slaptažodžio atstatymas</span></div>
            <?php
            if ($_GET['key'] && $_GET['token']) {
                $check = new User();
                $check->ResetPasswordUse($_GET['key'], $_GET['token']);
            }
            ?>
        </div>
    </div>
</body>
</html>