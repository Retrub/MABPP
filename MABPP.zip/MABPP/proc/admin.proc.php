<?php
include 'user.proc.php';
class Admin extends User
{

    public function GetAllUsers()
    {
        $db = $this->db_connect();
        $tableName = "vartotojai";
        $columns = ['ID', 'name', 'email', 'role'];
        $fetch_data = $this->fetch_data($db, $tableName, $columns);
        return $fetch_data;
    }

    public function CreateNewUser($name, $email, $role)
    {
        $pwd = md5($email) . rand(10, 9999);
        $encrypted_pwd = md5($pwd);

        $sql = "SELECT * FROM vartotojai where email='$email'";
        $result = $this->db_connect()->query($sql);

        if (mysqli_num_rows($result) > 0) {
            print('<div class="form-group"> <h4>Toks el. pašto adresas sistemoje jau užregistruotas!</h4>');
        } else {
            if ($role >= 0 && $role <= 3) {
                $sql = "INSERT INTO vartotojai (name, email, password, role) VALUES ('$name','$email','$encrypted_pwd','$role')";
                $result = $this->db_connect()->query($sql) or die("Užklausa į DB nepavyko!");
                $Subject = "MABPP vartotojo slaptažodis";
                $Body = "Jūsų paskyra buvo sėkmingai sukurta. <br><br> Galite prisijungti prie svetainės, 
                            naudodami jums sugeneruotą slaptažodį: '. $pwd";
                $send = $this->SendMail($email, $Subject, $Body);
                if ($send == true) {
                    return '<div class="form-group"> <h4>Vartotojas sėkmingai sukurtas!</h4></div>';
                }
            }
            return '<div class="form-group"> <h4>Patikrinkite įvestus duomenis!</h4></div>';
        }
    }
    public function DeleteUser($id)
    {
        
        $sql = "DELETE FROM vartotojai where ID = '$id'";
        $result = $this->db_connect()->query($sql);
        
        
            return '<div class="form-group"> <h4>Vartotojas sėkmingai istrintas!</h4></div>';
        
    }
    public function EditUser($id,$name,$email,$role)
    {
        
        if (!empty($name)&&empty($email)&&empty($role)){
            $sql = "UPDATE vartotojai SET name = '$name' where ID = '$id'";
        } else if (empty($name)&&!empty($email)&&empty($role)){
            $sql = "UPDATE vartotojai SET email = '$email' where ID = '$id'";
        } else if (empty($name)&&empty($email)&&!empty($role)){
            $sql = "UPDATE vartotojai SET role = '$role' where ID = '$id'";
        } else if (!empty($name)&&!empty($email)&&empty($role)){
            $sql = "UPDATE vartotojai SET name = '$name', email = '$email' where ID = '$id'";
        } else if (!empty($name)&&empty($email)&&!empty($role)){
            $sql = "UPDATE vartotojai SET name = '$name', role = '$role' where ID = '$id'";
        } else if (empty($name)&&!empty($email)&&!empty($role)){
            $sql = "UPDATE vartotojai SET email = '$email', role = '$role' where ID = '$id'";
        } else if (!empty($name)&&!empty($email)&&!empty($role)){
            $sql = "UPDATE vartotojai SET name = '$name', email = '$email', role = '$role' where ID = '$id'";
        }
            $result = $this->db_connect()->query($sql);
            return '<div class="form-group"> <h4>Vartotojas sėkmingai paredaguotas!</h4></div>';
        
        if (empty($name)&&empty($email)&&empty($role)){
            return '<div class="form-group"> <h4>Norint redaguoti vartotoja, reikia uzpildyti bent viena lauka</h4></div>';
        }
    }
    
}
