<?php
session_start();
$_SESSION['User'] = 9;
session_unset();
session_destroy();
header("Location:../welcome.php");
