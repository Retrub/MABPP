<?php
include 'database.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

class User extends Database
{

    public function Login($email, $password)
    {
        $encrypted_pwd = md5($password);
        $sql = "SELECT * FROM vartotojai where email='$email' and password='$encrypted_pwd'";
        $result = $this->db_connect()->query($sql);

        $row  = mysqli_fetch_array($result);
        if (is_array($row)) {
            $conn = "SELECT role FROM vartotojai where email='$email'";
            $role = $this->db_connect()->query($conn);
            $_SESSION['User'] = 9;
            $singleRow = mysqli_fetch_assoc($role);
            if ($singleRow['role'] == 1) {
                $_SESSION['User'] = 1;
                header("Location: html/User_homepage.php");
            }
            if ($singleRow['role'] == 2) {
                $_SESSION['User'] = 2;
                header("Location: html/Employee_homepage.php");
            }
            if ($singleRow['role'] == 3) {
                $_SESSION['User'] = 3;
                header("Location: html/Admin_homepage.php");
            }
        } else {
            session_destroy();
            echo "<h4>Neteisingas El. paštas arba Slaptažodis</h4><br>";
        }
    }

    public function Register($name, $email, $pass, $passr)
    {
        $encrypted_pwd = md5($pass);
        $sql = "SELECT * FROM vartotojai where email='$email'";
        $result = $this->db_connect()->query($sql);

        if (mysqli_num_rows($result) > 0) {
            print('<div class="form-group"> <h4>Toks el. pašto adresas sistemoje jau užregistruotas!</h4>');
        } else if ($pass != $passr) {
            print('<div class="form-group"> <h4>Slaptažodžiai nesutampa</h4>');
        } else if (isset($_POST['save'])) {
            $sql = "INSERT INTO vartotojai (name, email, password, role) VALUES ('$name','$email','$encrypted_pwd','0')";
            $result = $this->db_connect()->query($sql) or die("Užklausa į DB nepavyko!");
            header("Location: login.php?status=success");
        }
    }

    protected function SendMail($email, $subject, $body)
    {
        $mail = new PHPMailer();

        $mail->CharSet =  "utf-8";
        $mail->IsSMTP();
        // enable SMTP authentication
        $mail->SMTPAuth = true;
        // username
        $mail->Username = "pastas@Yahoo.com";
        // password
        $mail->Password = "password";
        $mail->SMTPSecure = "ssl";
        // sets yahoo as the SMTP server
        $mail->Host = "smtp.mail.yahoo.com";
        // set the SMTP port for the yahoo server
        $mail->Port = "465";
        $mail->From = 'pastas@Yahoo.com';
        $mail->FromName = 'MABPP - Projektas';
        $mail->AddAddress($email);
        $mail->Subject  =  $subject;
        $mail->IsHTML(true);
        $mail->Body = $body;
        if ($mail->Send()) {
            return true;
        } else {
            return $mail->ErrorInfo;
        }
    }

    public function ResetPasswordCreate($email)
    {
        $sql = "SELECT * FROM vartotojai WHERE email='" . $email . "'";
        $result = $this->db_connect()->query($sql);

        $row = mysqli_fetch_array($result);

        if ($row) {
            $token = md5($email) . rand(10, 9999);
            $expFormat = mktime(
                date("H"),
                date("i"),
                date("s"),
                date("m"),
                date("d") + 1,
                date("Y")
            );
            $expDate = date("Y-m-d H:i:s", $expFormat);

            $sql = "UPDATE vartotojai set reset_link_token='" . $token . "' ,exp_date='" . $expDate . "' WHERE email='" . $email . "'";
            $result = $this->db_connect()->query($sql);
            $link = "<a href='http://localhost/Model2/reset_pass.php?key=" . $email . "&token=" . $token . "'>Nuoroda</a>";
            $linkb = "http://localhost/Model2/reset_pass.php?key=" . $email . "&token=" . $token;
            $subject = "Reset Password";
            $body = "Paspauskite šią nuorodą, kad susikurtumėte naują slaptažodį: ' . $link . '<br><br> Pilna nuoroda: ' . $linkb";

            $send = $this->SendMail($email, $subject, $body);
            if ($send == true) {
                echo "Slaptažodžio atstatymo nuoroda sėkmingai išsiųsta į el. paštą! <br><br>";
            } else {
                echo "Įvyko klaida! - >" . $send;
            }
        } else {
            echo "Įvestas el. paštas sistemoje neegzistuoja! <br><br>";
        }
    }

    public function ResetPasswordUse($email, $token)
    {
        $sql = "SELECT * FROM `vartotojai` WHERE `reset_link_token`='" . $token . "' and `email`='" . $email . "';";
        $result = $this->db_connect()->query($sql);
        $curDate = date("Y-m-d H:i:s");

        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_array($result);
            if ($row['exp_date'] >= $curDate) { ?>
                <form method="post" enctype="multipart/form-data">
                    <input type="hidden" name="email" value="<?php echo $email; ?>">
                    <input type="hidden" name="reset_link_token" value="<?php echo $token; ?>">
                    <div class="row">
                        <i class="fas fa-lock"></i>
                        <input type="password" name='password' placeholder="Naujas slaptažodis" minlength="8" required="required">
                    </div>
                    <div class="row">
                        <i class="fas fa-lock"></i>
                        <input type="password" name='cpassword' placeholder="Pakartokite slaptažodis" minlength="8" required="required">
                    </div>
                    <div class="row button">
                        <input type="submit" name="new-password" value="Atstatyti slaptažodį">
                    </div>
                </form>
            <?php
            }
        } else { ?>
            <form>
                <div class="signup-link">Slaptažodžio atstatymo nuoroda nebegalioja. <br><br></div>
                <div class="signup-link"><a href="login.php">Grįžti į prisijungimo puslapį</a></div>
            </form>
            <?php
        }
        if (isset($_POST['password']) && $_POST['reset_link_token'] && $_POST['email'] && $_POST['new-password']) {
            if ($_POST['password'] != $_POST['cpassword']) { ?>
                <form>
                    <div class="signup-link">Įvesti slaptažodžiai nesutampa! <br></div>
                </form>
                <?php
            } else {
                $emailId = $_POST['email'];
                $token = $_POST['reset_link_token'];
                $password = md5($_POST['password']);
                $sql = "SELECT * FROM `vartotojai` WHERE `reset_link_token`='" . $token . "' and `email`='" . $emailId . "'";
                $result = $this->db_connect()->query($sql);

                $row = mysqli_num_rows($result);
                if ($row) {
                    $sql = "UPDATE vartotojai set  password='" . $password . "', reset_link_token='" . NULL . "' ,exp_date='" . NULL . "' WHERE email='" . $emailId . "'";
                    $result = $this->db_connect()->query($sql);
                ?>
                    <form>
                        <div class="signup-link">Jūsų slaptažodis buvo sėkmingai pakeistas!<br><br></div>
                        <div class="signup-link"><a href="login.php">Grįžti į prisijungimo puslapį</a></div>
                    </form>
<?php
                }
            }
        }
    }

    public function fetch_data($db, $tableName, $columns)
    {
        if (empty($db)) {
            $msg = "Database connection error";
        } elseif (empty($columns) || !is_array($columns)) {
            $msg = "columns Name must be defined in an indexed array";
        } elseif (empty($tableName)) {
            $msg = "Table Name is empty";
        } else {
            $columnName = implode(", ", $columns);
            $query = "SELECT " . $columnName . " FROM $tableName" . " ORDER BY id DESC LIMIT 10";
            $result = $db->query($query);
            if ($result == true) {
                if ($result->num_rows > 0) {
                    $row = mysqli_fetch_all($result, MYSQLI_ASSOC);
                    $msg = $row;
                } else {
                    $msg = "No Data Found";
                }
            } else {
                $msg = mysqli_error($db);
            }
        }
        return $msg;
    }
}
