<?php

class Database
{
	private $sname;
	private $uname;
	private $password;
	private $db_name;

	protected function db_connect()
	{
		$this->sname = "localhost";
		$this->uname = "root";
		$this->password = "root";
		$this->db_name = "dbdemo";

		try {

			$conn = new mysqli($this->sname, $this->uname, $this->password, $this->db_name);
			return $conn;

		} catch (mysqli_sql_exception $e) {

			die($e->getMessage());
		}
	}
}
