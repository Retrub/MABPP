<?php
include 'user.proc.php';

class Client extends User
{
    public function SearchRoute($prad, $gal, $isv, $atv)
    {
        if (empty($isv) && empty($atv)) {
            $sqlquery = "SELECT * from marsrutai where pradine='$prad' and galutine='$gal' ORDER BY isvykimas ASC LIMIT 10";
        } elseif (!empty($isv) && empty($atv)) {
            $sqlquery = "SELECT * from marsrutai where pradine='$prad' and galutine='$gal' and isvykimas >= '$isv' ORDER BY isvykimas ASC";
        } elseif (empty($isv) && !empty($atv)) {
            $sqlquery = "SELECT * from marsrutai where pradine='$prad' and galutine='$gal' and atvykimas <= '$atv' ORDER BY atvykimas ASC";
        } else {
            $sqlquery = "SELECT * from marsrutai where pradine='$prad' and galutine='$gal' and isvykimas >= '$isv' and atvykimas <= '$atv' ORDER BY isvykimas ASC";
        }
        
        $result = $this->db_connect()->query($sqlquery);
        return $result;
    }


    public function GetAllRoutes()
    {
        $db = $this->db_connect();
        $tableName = "marsrutai";
        $columns = ['ID', 'pradine', 'galutine', 'isvykimas', 'atvykimas'];
        $fetch_data = $this->fetch_data($db, $tableName, $columns);
        return $fetch_data;
    }
}
