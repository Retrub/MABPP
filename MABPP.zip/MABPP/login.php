<?php
session_start();
if ($_SESSION['User'] != 9) {
    if ($_SESSION['User'] == 1) {
        header("Location: html/User_homepage.php");
    } elseif ($_SESSION['User'] == 2) {
        header("Location: html/Employee_homepage.php");
    } elseif ($_SESSION['User'] == 3) {
        header("Location: html/Admin_homepage.php");
    }
}
include 'proc/user.proc.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Mobili autobusų bilietų pirkimo programėlė</title>
    <link rel="stylesheet" href="html/Styles/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" />
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,700' rel='stylesheet' type='text/css'>
    <link href="html/css/font-awesome.min.css" rel="stylesheet">
    <link href="html/css/bootstrap.min.css" rel="stylesheet">
    <link href="html/css/templatemo-style.css" rel="stylesheet">
    <style>
        html,
        body {
            height: 100%;
            margin: 0;
        }

        body {
            background-image: url('https://img.besthqwallpapers.com/Uploads/8-3-2020/124199/man-lions-city-18-g-4k-road-2020-buses-passenger-transport.jpg');
            background-position-x: 20%;
            background-size: cover;
            overflow-y:scroll;
        }
    </style>
</head>

<div class="templatemo-flex-row">
    <div class="templatemo-sidebar">
        <header class="templatemo-site-header">
            <div class="square"></div>
            <h1><a style="color:white; font-weight:500;" href="welcome.php"> MABPP</a></h1>
            <hr>
            <br>
        </header>
    </div>
</div>
<div style="background: rgba(36, 206, 172, 0.6); font-size: 25px; display: flex; margin-top: -50px; align-items: center; justify-content: center;">
    <p>Autobusų bilietai</p>
</div>

<body>
    <div class="container">
        <div class="wrapper">
            <div class="title"><span>Prisijungimas</span></div>
            <form method="post" enctype="multipart/form-data">
                <div class="row">
                    <i class="fas fa-user"></i>
                    <input type="email" name="email" placeholder="El. paštas" required>
                </div>
                <div class="row">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="pawd" placeholder="Slaptažodis" required="required">
                </div>

                <?php
                if (isset($_POST['save'])) {
                    $login = new User();
                    $login->Login($_POST['email'], $_POST['pawd']);
                }
                ?>
                <div class="pass">
                    <p>Pamiršote slaptažodį? <a href="reset_pass_email.php">Spauskite čia!</a></p>
                </div>
                <div class="row button">
                    <input type="submit" name="save" value="Prisijungti">
                </div>
                <div class="signup-link">Esate neprisiregistravęs? <a href="register.php">Registruotis</a></div>
            </form>
        </div>
    </div>
</body>

</html>